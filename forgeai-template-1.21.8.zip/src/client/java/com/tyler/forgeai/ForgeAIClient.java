package com.tyler.forgeai;

import net.fabricmc.api.ClientModInitializer;

public class ForgeAIClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}